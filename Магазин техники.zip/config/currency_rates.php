<?php

return [
    'api_url' => 'https://api.exchangeratesapi.io/latest',
];
