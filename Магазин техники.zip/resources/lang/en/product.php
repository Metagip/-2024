<?php

return [
    'price' => 'Price',
    'add_to_cart' => 'Add to Cart',
    'tell_me' => 'Tell me, when it will be available',
    'subscribe' => 'Subscribe',
    'we_will_update' => 'We will update you, when the product will be available',
    'not_available' => 'Product is not available',
];
