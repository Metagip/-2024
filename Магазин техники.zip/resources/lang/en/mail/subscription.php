<?php

return [
    'dear_client' => 'Dear client, the product ',
    'appeared_in_stock' => 'has been appeared in stock',
    'more_info' => 'Get more about it',
];
