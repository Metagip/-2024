<?php

return [
    'dear' => 'Dear',
    'your_order' => 'Your order costs ',
    'created' => ' was created',
];
