<?php

return [
    'dear_client' => 'Уважаемый клиент, товар',
    'appeared_in_stock' => 'появился в наличии',
    'more_info' => 'Узнать подробности',
];
