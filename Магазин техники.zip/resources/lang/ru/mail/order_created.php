<?php

return [
    'dear' => 'Уважаемый',
    'your_order' => 'Ваш заказ на сумму ',
    'created' => ' создан',
];
